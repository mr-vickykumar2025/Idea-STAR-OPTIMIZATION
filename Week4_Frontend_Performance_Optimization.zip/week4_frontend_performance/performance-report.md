# Week 4 Task: Frontend Performance Optimization Report

## 1. Project overview
**Project name:** Idea Star — Learn, Build, Grow  
**Technology:** HTML5, CSS3, vanilla JavaScript  
**Goal:** Improve loading behavior, responsiveness, maintainability, and user experience using practical frontend performance techniques.

## 2. Baseline review and likely bottlenecks
The starter concept was reviewed for common sources of avoidable work. No original Lighthouse report was supplied, so these are code-review findings and test hypotheses—not claimed measured failures.

| Area | Potential issue in a typical unoptimized page | How to verify |
|---|---|---|
| Images | Large, uncompressed images can increase transfer size and delay Largest Contentful Paint (LCP). | Lighthouse: properly size images / image delivery insights; Network panel transfer size |
| JavaScript | Blocking scripts can delay HTML parsing and first render. | Inspect script tags and Lighthouse diagnostics |
| CSS | Large unused stylesheets and complex selectors can increase bytes and style calculation. | Coverage panel; Lighthouse unused CSS insight |
| DOM | Excessive nested elements increase style/layout work. | Elements panel; Lighthouse DOM-size diagnostic |
| Fonts and third parties | External font requests, trackers, and libraries add network connections and execution. | Network panel and request waterfall |
| Layout and accessibility | Missing responsive layout or reduced-motion support can hurt usability. | Responsive mode; accessibility checks |

## 3. Optimizations implemented
1. **Small dependency-free page:** Uses semantic HTML, CSS, and vanilla JavaScript instead of a framework or large UI library.
2. **Deferred JavaScript:** `js/app.js` uses `defer`, so it does not block HTML parsing.
3. **No external assets:** The hero illustration is drawn with CSS shapes. This avoids image downloads, remote font requests, and third-party requests for this demo.
4. **Compact JavaScript:** The script contains only the small interactions required by the page and checks that elements exist before using them.
5. **Responsive CSS:** Grid layouts adapt to smaller screens using a focused media query.
6. **Reduced-motion support:** The stylesheet respects `prefers-reduced-motion`.
7. **Efficient page structure:** Content uses semantic landmarks and a limited, purposeful DOM structure.
8. **Caching strategy guidance:** For production hosting, configure long-lived `Cache-Control` headers for versioned static assets and revalidate HTML. Headers are server/CDN settings and cannot be configured from a standalone HTML file.
9. **Minification guidance:** Keep source files readable during development; minify CSS/JS in a production build when a build/deployment pipeline is available. This simple project has no build dependencies, so the source is kept maintainable.

### Why lazy loading is not applied
This page intentionally has no content images. Lazy loading is useful for below-the-fold images, but adding an image just to demonstrate lazy loading would introduce unnecessary network work. If real below-the-fold images are added, use `loading="lazy"`, explicit `width` and `height`, and appropriately sized WebP/AVIF assets. Do not lazy-load the main above-the-fold/LCP image.

## 4. Before-and-after measurement
Run tests before and after any further changes using the same Chrome version, device mode, URL, and network conditions. Run Lighthouse at least three times per state and compare the median to reduce run-to-run noise.

| Metric | Baseline score/result | Optimized score/result |
|---|---|---|
| Performance score (0–100) | Record actual baseline | Record actual optimized result |
| First Contentful Paint (FCP) | Record actual baseline | Record actual optimized result |
| Largest Contentful Paint (LCP) | Record actual baseline | Record actual optimized result |
| Total Blocking Time (TBT) | Record actual baseline | Record actual optimized result |
| Cumulative Layout Shift (CLS) | Record actual baseline | Record actual optimized result |
| Total transfer size / requests | Record actual baseline | Record actual optimized result |

**Important:** Scores are intentionally left blank until real Lighthouse runs are completed. A verified numerical improvement cannot be claimed without the baseline report and post-change test output.

### How to capture the results
1. If a previous project is available, run Lighthouse on its original version first and save the report as the baseline.
2. Serve this optimized folder on localhost or deploy it to a test URL.
3. Open Chrome DevTools → **Lighthouse**.
4. Select **Mobile** first, then run **Desktop** separately. Use the same categories and settings for both versions.
5. Save each HTML report and enter the displayed metrics in the table above.
6. Review the Opportunities/Insights section and fix the highest-impact issues first.
7. Repeat each run three times and use the median for comparison.

## 5. Expected impact and limitations
The implemented page removes common avoidable costs such as third-party requests, external font downloads, large image downloads, and parser-blocking JavaScript. The actual score depends on the test environment, browser version, device emulation, and hosting. CSS rendering and main-thread work still occur, and a local file test may not represent production caching or compression.

## 6. Challenges encountered
- A real baseline requires the original page and an actual Lighthouse report; neither can be inferred reliably from a task brief.
- Caching headers and server-side compression require hosting/CDN configuration, so they are documented as deployment steps rather than falsely claimed as implemented.
- Lazy loading is not appropriate when a page has no below-the-fold image assets.
- Performance scores vary between runs, so consistent conditions and repeated tests are necessary.

## 7. Conclusion
Idea Star demonstrates a lightweight front-end implementation with deferred JavaScript, responsive CSS, minimal DOM complexity, no external dependencies, and reduced-motion support. To complete the measurement portion of the assignment, attach actual baseline and optimized Lighthouse reports and fill in the results table. The code changes are implemented; numerical performance gains should only be reported after measurement.
