'use strict';

const yearElement = document.getElementById('year');
const startButton = document.getElementById('start-button');
const startMessage = document.getElementById('start-message');

if (yearElement) {
  yearElement.textContent = String(new Date().getFullYear());
}

if (startButton && startMessage) {
  startButton.addEventListener('click', () => {
    startMessage.textContent = 'Great ideas begin with a first step. Choose one small action and get started!';
  });
}
